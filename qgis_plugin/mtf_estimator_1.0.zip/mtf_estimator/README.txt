Find the documentation on https://github.com/JorgeGIlG/MTF_Estimator
